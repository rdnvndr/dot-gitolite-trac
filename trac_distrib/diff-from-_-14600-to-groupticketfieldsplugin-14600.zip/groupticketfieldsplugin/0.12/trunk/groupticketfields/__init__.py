# -*- coding: utf-8 -*-
#
# Copyright (C) 2012 Thomas Doering
#

from ticket import *

__version__ = __import__('pkg_resources').get_distribution('GroupTicketFields').version
