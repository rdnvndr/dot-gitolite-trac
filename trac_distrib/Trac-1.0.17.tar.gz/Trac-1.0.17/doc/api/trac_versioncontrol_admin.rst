:mod:`trac.versioncontrol.admin`
================================

.. automodule :: trac.versioncontrol.admin
   :members:

