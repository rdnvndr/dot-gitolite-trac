:mod:`tracopt.versioncontrol.git.PyGIT`
=======================================

.. automodule :: tracopt.versioncontrol.git.PyGIT
   :members:

.. autofunction :: parse_commit

.. autoclass :: GitCore
   :members:

.. autoclass :: SizedDict
   :members:
