:mod:`tracopt.ticket.deleter`
=============================

.. automodule :: tracopt.ticket.deleter
   :members:

