:mod:`trac.wiki.formatter`
==========================

.. automodule :: trac.wiki.formatter
   :members:

Components
----------

.. autoclass :: HtmlFormatter
   :members:

.. autoclass :: InlineHtmlFormatter
   :members:

.. autoclass :: LinkFormatter
   :members:

.. autoclass :: OneLinerFormatter
   :members:

.. autoclass :: OutlineFormatter
   :members:
