:mod:`tracopt.ticket.commit_updater`
====================================

.. automodule :: tracopt.ticket.commit_updater
   :members:

