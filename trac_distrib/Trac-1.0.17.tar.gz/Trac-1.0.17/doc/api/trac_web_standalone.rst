:mod:`trac.web.standalone`
==========================

.. automodule :: trac.web.standalone
   :members:

