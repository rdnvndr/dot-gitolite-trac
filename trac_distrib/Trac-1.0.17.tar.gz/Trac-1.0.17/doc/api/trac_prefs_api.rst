:mod:`trac.prefs.api`
=====================

.. automodule :: trac.prefs.api
   :members:

