
The AutocompleteUsersPlugin allows AJAX completion of users
for the owner, reporter and CC fields on new and existing tickets.

see also: http://trac-hacks.org/wiki/AutocompleteUsersPlugin
